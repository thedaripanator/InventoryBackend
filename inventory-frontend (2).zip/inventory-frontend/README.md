# Inventory Management System — Frontend

A React frontend for the Spring Boot Inventory Management System backend.

---

## Tech Stack

| Layer     | Technology             |
|-----------|------------------------|
| Framework | React 18               |
| Routing   | React Router v6        |
| HTTP      | Axios                  |
| Icons     | Inline SVG (no deps)   |
| Fonts     | Syne + DM Sans (Google)|

---

## Project Structure

```
src/
├── components/
│   ├── Sidebar.js          ← Navigation sidebar
│   ├── Topbar.js           ← Top header bar
│   ├── Modal.js            ← Reusable modal wrapper
│   └── ConfirmDialog.js    ← Delete confirmation dialog
├── pages/
│   ├── Dashboard.js        ← Overview stats + recent products
│   ├── Categories.js       ← Category CRUD
│   └── Products.js         ← Product CRUD
├── services/
│   ├── axiosConfig.js      ← Axios instance (base URL here)
│   ├── categoryService.js  ← Category API calls
│   └── productService.js   ← Product API calls
├── index.css               ← Global styles (CSS variables)
├── index.js                ← React entry point
└── App.js                  ← Router setup
```

---

## Prerequisites

- Node.js ≥ 16
- npm ≥ 8
- Spring Boot backend running on `http://localhost:8081`

---

## Setup & Run

```bash
# 1. Install dependencies
npm install

# 2. Start the dev server
npm start
```

The app will open at **http://localhost:3000**

---

## Connecting to the Spring Boot Backend

The base URL is configured in one place:

```
src/services/axiosConfig.js
```

```js
const API = axios.create({
  baseURL: 'http://localhost:8081',   // ← change this if your backend runs elsewhere
});
```

### CORS — required on the Spring Boot side

Add this annotation to your Spring Boot controllers (or a global config):

```java
@CrossOrigin(origins = "http://localhost:3000")
```

Or globally in a `WebMvcConfigurer` bean:

```java
@Configuration
public class CorsConfig implements WebMvcConfigurer {
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
                .allowedOrigins("http://localhost:3000")
                .allowedMethods("GET", "POST", "PUT", "DELETE");
    }
}
```

---

## API Endpoints Used

### Category
| Method | Endpoint              | Service call                    |
|--------|-----------------------|---------------------------------|
| GET    | /category/all         | `categoryService.getAllCategories()` |
| POST   | /category/add         | `categoryService.addCategory(data)`  |
| DELETE | /category/delete/{id} | `categoryService.deleteCategory(id)` |

### Products
| Method | Endpoint               | Service call                         |
|--------|------------------------|--------------------------------------|
| GET    | /products/all          | `productService.getAllProducts()`     |
| POST   | /products/add          | `productService.addProduct(data)`     |
| PUT    | /products/edit/{id}    | `productService.updateProduct(id, d)` |
| DELETE | /products/delete/{id}  | `productService.deleteProduct(id)`    |

---

## Adapting to Your Model Field Names

The Products page uses a normalisation helper to handle common Spring Boot field name variations:

```js
// src/pages/Products.js
const getName  = (p) => p.name || p.productName || '';
const getPrice = (p) => p.price ?? p.productPrice ?? '';
const getQty   = (p) => p.quantity ?? p.stock ?? '';
const getCatId = (p) => p.category?.id ?? p.categoryId ?? '';
```

If your model uses different field names, update these helpers.

The POST/PUT payload sent to the backend:

```json
{
  "name": "...",
  "description": "...",
  "price": 0.0,
  "quantity": 0,
  "category": { "id": 1 }
}
```

Adjust the payload shape in `handleSubmit` inside `Products.js` to match your backend model exactly.

---

## Build for Production

```bash
npm run build
```

Output will be in the `build/` directory, ready to serve as static files.
