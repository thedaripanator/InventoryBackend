import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import categoryService from '../services/categoryService';
import productService from '../services/productService';

const IconPackage = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/>
    <polyline points="3.27 6.96 12 12.01 20.73 6.96"/>
    <line x1="12" y1="22.08" x2="12" y2="12"/>
  </svg>
);

const IconTag = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"/>
    <line x1="7" y1="7" x2="7.01" y2="7"/>
  </svg>
);

const IconArrow = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <line x1="5" y1="12" x2="19" y2="12"/>
    <polyline points="12 5 19 12 12 19"/>
  </svg>
);

const IconTrend = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/>
    <polyline points="17 6 23 6 23 12"/>
  </svg>
);

export default function Dashboard() {
  const navigate = useNavigate();
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        const [p, c] = await Promise.all([
          productService.getAllProducts(),
          categoryService.getAllCategories(),
        ]);
        setProducts(Array.isArray(p) ? p : []);
        setCategories(Array.isArray(c) ? c : []);
      } catch {
        // silently fail — show zeros
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  const recentProducts = [...products].slice(-5).reverse();

  return (
    <div>
      <div className="page-header">
        <div className="page-header-text">
          <h1>Overview</h1>
          <p>Welcome back — here's a snapshot of your inventory.</p>
        </div>
      </div>

      {/* Stats */}
      <div className="stats-grid">
        <div className="stat-card yellow">
          <div className="stat-icon yellow"><IconPackage /></div>
          <div className="stat-value">{loading ? '—' : products.length}</div>
          <div className="stat-label">Total Products</div>
        </div>
        <div className="stat-card green">
          <div className="stat-icon green"><IconTag /></div>
          <div className="stat-value">{loading ? '—' : categories.length}</div>
          <div className="stat-label">Categories</div>
        </div>
        <div className="stat-card blue">
          <div className="stat-icon blue"><IconTrend /></div>
          <div className="stat-value">{loading ? '—' : (products.length > 0 ? (products.length / Math.max(categories.length, 1)).toFixed(1) : '0')}</div>
          <div className="stat-label">Avg per Category</div>
        </div>
      </div>

      {/* Quick Actions */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 28 }}>
        <div className="card" style={{ cursor: 'pointer' }} onClick={() => navigate('/categories')}>
          <div className="card-body" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 13, fontWeight: 700, marginBottom: 4 }}>
                Manage Categories
              </div>
              <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>
                {loading ? '…' : `${categories.length} categories`}
              </div>
            </div>
            <span style={{ color: 'var(--accent)' }}><IconArrow /></span>
          </div>
        </div>
        <div className="card" style={{ cursor: 'pointer' }} onClick={() => navigate('/products')}>
          <div className="card-body" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 13, fontWeight: 700, marginBottom: 4 }}>
                Manage Products
              </div>
              <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>
                {loading ? '…' : `${products.length} products`}
              </div>
            </div>
            <span style={{ color: 'var(--accent)' }}><IconArrow /></span>
          </div>
        </div>
      </div>

      {/* Recent Products */}
      <div className="card">
        <div className="card-header">
          <span className="card-title">Recent Products</span>
          <button className="btn btn-secondary btn-sm" onClick={() => navigate('/products')}>
            View All <IconArrow />
          </button>
        </div>
        <div className="table-wrapper">
          {loading ? (
            <div className="spinner"><div className="spinner-ring" /></div>
          ) : recentProducts.length === 0 ? (
            <div className="empty-state">
              <IconPackage />
              <p>No products yet. Add your first product.</p>
            </div>
          ) : (
            <table>
              <thead>
                <tr>
                  <th>#</th>
                  <th>Name</th>
                  <th>Category</th>
                  <th>Price</th>
                  <th>Quantity</th>
                </tr>
              </thead>
              <tbody>
                {recentProducts.map((p) => (
                  <tr key={p.id}>
                    <td className="td-id">{p.id}</td>
                    <td className="td-name">{p.name || p.productName}</td>
                    <td>
                      <span className="badge badge-yellow">
                        {p.category?.name || p.categoryName || 'N/A'}
                      </span>
                    </td>
                    <td>{p.price != null ? `₹${Number(p.price).toFixed(2)}` : '—'}</td>
                    <td>{p.quantity ?? p.stock ?? '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}
