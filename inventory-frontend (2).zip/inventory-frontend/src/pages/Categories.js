import React, { useEffect, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import categoryService from '../services/categoryService';
import Modal from '../components/Modal';
import ConfirmDialog from '../components/ConfirmDialog';

/* ── Icons ── */
const IconPlus = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
    <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
  </svg>
);
const IconEdit = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
    <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
  </svg>
);
const IconTrash = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/>
    <path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4h6v2"/>
  </svg>
);
const IconTag = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"/>
    <line x1="7" y1="7" x2="7.01" y2="7"/>
  </svg>
);
const IconCheck = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
    <polyline points="20 6 9 17 4 12"/>
  </svg>
);
const IconAlertCircle = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="10"/>
    <line x1="12" y1="8" x2="12" y2="12"/>
    <line x1="12" y1="16" x2="12.01" y2="16"/>
  </svg>
);

/* ── Inline icon button ── */
function IconBtn({ children, title, variant, onClick }) {
  const [hover, setHover] = useState(false);
  const styles = {
    edit:   { hoverBg: 'var(--accent-dim)',  hoverColor: 'var(--accent)' },
    danger: { hoverBg: 'var(--danger-dim)',  hoverColor: 'var(--danger)' },
  };
  const s = styles[variant] || styles.edit;
  return (
    <button
      title={title}
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        padding: '6px',
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
        cursor: 'pointer',
        borderRadius: 'var(--radius-sm)',
        border: '1px solid var(--border)',
        background: hover ? s.hoverBg : 'var(--bg-elevated)',
        color: hover ? s.hoverColor : 'var(--text-secondary)',
        transition: 'all var(--transition)',
      }}
    >
      {children}
    </button>
  );
}

const EMPTY_FORM = { name: '' };

export default function Categories() {
  const navigate = useNavigate();

  const [categories,   setCategories]   = useState([]);
  const [loading,      setLoading]      = useState(true);
  const [showModal,    setShowModal]    = useState(false);
  const [editTarget,   setEditTarget]   = useState(null); // null = add mode
  const [form,         setForm]         = useState(EMPTY_FORM);
  const [saving,       setSaving]       = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleting,     setDeleting]     = useState(false);
  const [alert,        setAlert]        = useState(null);

  const flash = (type, msg) => {
    setAlert({ type, msg });
    setTimeout(() => setAlert(null), 3500);
  };

  const loadCategories = useCallback(async () => {
    setLoading(true);
    try {
      const data = await categoryService.getAllCategories();
      setCategories(Array.isArray(data) ? data : []);
    } catch {
      flash('error', 'Failed to load categories. Is the backend running?');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadCategories(); }, [loadCategories]);

  /* ── Open Add modal ── */
  const openAdd = () => {
    setEditTarget(null);
    setForm(EMPTY_FORM);
    setShowModal(true);
  };

  /* ── Open Edit modal ── */
  const openEdit = (cat) => {
    setEditTarget(cat);
    setForm({ name: cat.name });
    setShowModal(true);
  };

  /* ── Submit add or edit ── */
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.name.trim()) return;
    setSaving(true);
    try {
      if (editTarget) {
        // PUT /category/add/{id}
        await categoryService.editCategory(editTarget.id, { name: form.name.trim() });
        flash('success', `Category renamed to "${form.name}".`);
      } else {
        // POST /category/add
        await categoryService.addCategory({ name: form.name.trim() });
        flash('success', `Category "${form.name}" added.`);
      }
      setShowModal(false);
      loadCategories();
    } catch (err) {
      flash('error', err?.response?.data?.message || 'Operation failed.');
    } finally {
      setSaving(false);
    }
  };

  /* ── Delete ── */
  const handleDelete = async () => {
    setDeleting(true);
    try {
      await categoryService.deleteCategory(deleteTarget.id);
      flash('success', `Category "${deleteTarget.name}" deleted.`);
      setDeleteTarget(null);
      loadCategories();
    } catch (err) {
      flash('error', err?.response?.data?.message || 'Failed to delete category.');
      setDeleteTarget(null);
    } finally {
      setDeleting(false);
    }
  };

  const isAdd = !editTarget;

  return (
    <div>
      {/* Page header */}
      <div className="page-header">
        <div className="page-header-text">
          <h1>Categories</h1>
          <p>Organise your products into categories.</p>
        </div>
        <button className="btn btn-primary" onClick={openAdd}>
          <IconPlus /> Add Category
        </button>
      </div>

      {/* Alert */}
      {alert && (
        <div className={`alert alert-${alert.type === 'error' ? 'error' : 'success'}`}>
          {alert.type === 'error' ? <IconAlertCircle /> : <IconCheck />}
          {alert.msg}
        </div>
      )}

      {/* Table */}
      <div className="card">
        <div className="card-header">
          <span className="card-title">All Categories</span>
          <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>{categories.length} total</span>
        </div>
        <div className="table-wrapper">
          {loading ? (
            <div className="spinner"><div className="spinner-ring" /></div>
          ) : categories.length === 0 ? (
            <div className="empty-state">
              <IconTag />
              <p>No categories yet. Create your first one.</p>
            </div>
          ) : (
            <table>
              <thead>
                <tr>
                  <th>#</th>
                  <th>Category Name</th>
                  <th style={{ textAlign: 'right' }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {categories.map((cat) => (
                  <tr key={cat.id}>
                    <td className="td-id">{cat.id}</td>
                    <td className="td-name">
                      <span
                        onClick={() => navigate(`/products?categoryId=${cat.id}&categoryName=${encodeURIComponent(cat.name)}`)}
                        title={`View products in "${cat.name}"`}
                        style={{
                          display: 'flex', alignItems: 'center', gap: 8,
                          cursor: 'pointer',
                          color: 'var(--text-primary)',
                          transition: 'color var(--transition)',
                        }}
                        onMouseEnter={e => e.currentTarget.style.color = 'var(--accent)'}
                        onMouseLeave={e => e.currentTarget.style.color = 'var(--text-primary)'}
                      >
                        <span style={{ color: 'var(--accent)', opacity: 0.7, flexShrink: 0 }}>
                          <IconTag />
                        </span>
                        {cat.name}
                        <span style={{ marginLeft: 'auto', fontSize: 11, color: 'var(--text-muted)', paddingLeft: 8 }}>
                          View products →
                        </span>
                      </span>
                    </td>
                    <td>
                      <div style={{ display: 'flex', gap: 6, justifyContent: 'flex-end' }}>
                        <IconBtn title="Edit category" variant="edit" onClick={() => openEdit(cat)}>
                          <IconEdit />
                        </IconBtn>
                        <IconBtn title="Delete category" variant="danger" onClick={() => setDeleteTarget(cat)}>
                          <IconTrash />
                        </IconBtn>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {/* Add / Edit Modal */}
      {showModal && (
        <Modal
          title={isAdd ? 'Add Category' : `Edit — ${editTarget.name}`}
          onClose={() => setShowModal(false)}
        >
          <form onSubmit={handleSubmit} className="form-grid">
            <div className="form-group">
              <label htmlFor="cat-name">Category Name *</label>
              <input
                id="cat-name"
                type="text"
                placeholder="e.g. Electronics"
                value={form.name}
                onChange={(e) => setForm({ name: e.target.value })}
                required
                autoFocus
              />
            </div>
            <div className="form-actions">
              <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>
                Cancel
              </button>
              <button type="submit" className="btn btn-primary" disabled={saving || !form.name.trim()}>
                {saving ? 'Saving…' : isAdd ? 'Add Category' : 'Save Changes'}
              </button>
            </div>
          </form>
        </Modal>
      )}

      {/* Delete Confirm */}
      {deleteTarget && (
        <ConfirmDialog
          message={`Delete "${deleteTarget.name}"? This action cannot be undone.`}
          onConfirm={handleDelete}
          onCancel={() => setDeleteTarget(null)}
          loading={deleting}
        />
      )}
    </div>
  );
}
