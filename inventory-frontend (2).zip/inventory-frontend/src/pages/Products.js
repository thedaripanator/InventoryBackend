import React, { useEffect, useState, useCallback } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import productService from '../services/productService';
import categoryService from '../services/categoryService';
import Modal from '../components/Modal';
import ConfirmDialog from '../components/ConfirmDialog';

/* ── Icons ── */
const IconPlus = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
    <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
  </svg>
);
const IconEdit = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
    <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
  </svg>
);
const IconTrash = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/>
    <path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4h6v2"/>
  </svg>
);
const IconPackage = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/>
    <polyline points="3.27 6.96 12 12.01 20.73 6.96"/>
    <line x1="12" y1="22.08" x2="12" y2="12"/>
  </svg>
);
const IconSearch = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
  </svg>
);
const IconFilter = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/>
  </svg>
);
const IconX = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
    <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
  </svg>
);
const IconCheck = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
    <polyline points="20 6 9 17 4 12"/>
  </svg>
);
const IconAlertCircle = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="10"/>
    <line x1="12" y1="8" x2="12" y2="12"/>
    <line x1="12" y1="16" x2="12.01" y2="16"/>
  </svg>
);

/* ── Constants ── */
const EMPTY_FORM = { name: '', brand: '', description: '', price: '', quantity: '', categoryId: '' };

const FILTER_MODES = [
  { value: 'all',           label: 'All Products' },
  { value: 'name',          label: 'By Name' },
  { value: 'category_id',   label: 'By Category' },
  { value: 'category_name', label: 'By Category Name' },
  { value: 'price_range',   label: 'By Price Range' },
];

export default function Products() {
  const location = useLocation();
  const navigate = useNavigate();

  const [products,   setProducts]   = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading,    setLoading]    = useState(true);

  // Filter state
  const [filterMode,     setFilterMode]     = useState('all');
  const [filterName,     setFilterName]     = useState('');
  const [filterCatId,    setFilterCatId]    = useState('');
  const [filterCatName,  setFilterCatName]  = useState('');
  const [filterPriceMin, setFilterPriceMin] = useState('');
  const [filterPriceMax, setFilterPriceMax] = useState('');
  const [filterLoading,  setFilterLoading]  = useState(false);

  // Modal / CRUD state
  const [showModal,    setShowModal]    = useState(false);
  const [editTarget,   setEditTarget]   = useState(null);
  const [form,         setForm]         = useState(EMPTY_FORM);
  const [saving,       setSaving]       = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleting,     setDeleting]     = useState(false);

  const [alert, setAlert] = useState(null);

  const flash = (type, msg) => {
    setAlert({ type, msg });
    setTimeout(() => setAlert(null), 3500);
  };

  const loadAll = useCallback(async () => {
    setLoading(true);
    try {
      const [p, c] = await Promise.all([
        productService.getAllProducts(),
        categoryService.getAllCategories(),
      ]);
      setProducts(Array.isArray(p) ? p : []);
      setCategories(Array.isArray(c) ? c : []);
    } catch {
      flash('error', 'Failed to load data. Is the backend running on port 8081?');
    } finally {
      setLoading(false);
    }
  }, []);

  // On mount (or URL change): read ?categoryId= and auto-apply filter
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const catId   = params.get('categoryId');
    const catName = params.get('categoryName');

    const init = async () => {
      setLoading(true);
      try {
        const c = await categoryService.getAllCategories();
        setCategories(Array.isArray(c) ? c : []);

        if (catId) {
          setFilterMode('category_id');
          setFilterCatId(catId);
          const p = await productService.getProductsByCategory(catId);
          setProducts(Array.isArray(p) ? p : []);
        } else {
          setFilterMode('all');
          setFilterCatId('');
          const p = await productService.getAllProducts();
          setProducts(Array.isArray(p) ? p : []);
        }
      } catch {
        flash('error', 'Failed to load data. Is the backend running on port 8081?');
      } finally {
        setLoading(false);
      }
    };
    init();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [location.search]);

  /* ── Filter ── */
  const resetFilter = () => {
    setFilterMode('all');
    setFilterName(''); setFilterCatId('');
    setFilterCatName(''); setFilterPriceMin(''); setFilterPriceMax('');
    loadAll();
  };

  const applyFilter = async () => {
    setFilterLoading(true);
    try {
      let data;
      switch (filterMode) {
        case 'name':
          if (!filterName.trim()) return flash('error', 'Enter a product name to search.');
          data = await productService.getProductsByName(filterName.trim());
          break;
        case 'category_id':
          if (!filterCatId) return flash('error', 'Select a category.');
          data = await productService.getProductsByCategory(filterCatId);
          break;
        case 'category_name':
          if (!filterCatName.trim()) return flash('error', 'Enter a category name to search.');
          data = await productService.getProductsByCategoryName(filterCatName.trim());
          break;
        case 'price_range':
          if (!filterPriceMin || !filterPriceMax) return flash('error', 'Enter both min and max price.');
          if (parseFloat(filterPriceMin) > parseFloat(filterPriceMax)) return flash('error', 'Min price cannot exceed max price.');
          data = await productService.getProductsByPriceRange(filterPriceMin, filterPriceMax);
          break;
        default:
          data = await productService.getAllProducts();
      }
      setProducts(Array.isArray(data) ? data : []);
    } catch (err) {
      flash('error', err?.response?.data?.message || 'Filter failed.');
    } finally {
      setFilterLoading(false);
    }
  };

  const isFiltered = filterMode !== 'all';

  /* ── CRUD ── */
  const openAdd = () => {
    setEditTarget(null);
    setForm(EMPTY_FORM);
    setShowModal(true);
  };

  const openEdit = (product) => {
    setEditTarget(product);
    setForm({
      name:        product.name || '',
      brand:       product.brand || '',
      description: product.description || '',
      price:       product.price ?? '',
      quantity:    product.quantity ?? '',
      categoryId:  product.category?.id ?? '',
    });
    setShowModal(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    const payload = {
      name:        form.name.trim(),
      brand:       form.brand.trim(),
      description: form.description.trim(),
      price:       parseFloat(form.price) || 0,
      quantity:    parseInt(form.quantity) || 0,
      category:    form.categoryId ? { id: parseInt(form.categoryId) } : null,
    };
    try {
      if (editTarget) {
        await productService.updateProduct(editTarget.id, payload);
        flash('success', `Product "${form.name}" updated.`);
      } else {
        await productService.addProduct(payload);
        flash('success', `Product "${form.name}" added.`);
      }
      setShowModal(false);
      loadAll();
    } catch (err) {
      flash('error', err?.response?.data?.message || 'Operation failed.');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    setDeleting(true);
    try {
      await productService.deleteProduct(deleteTarget.id);
      flash('success', `"${deleteTarget.name}" deleted.`);
      setDeleteTarget(null);
      loadAll();
    } catch (err) {
      flash('error', err?.response?.data?.message || 'Delete failed.');
      setDeleteTarget(null);
    } finally {
      setDeleting(false);
    }
  };

  const getCatName = (p) => p.category?.name ?? 'Uncategorised';

  // Derive active category name from URL for breadcrumb
  const urlParams      = new URLSearchParams(location.search);
  const activeCatName  = urlParams.get('categoryName');

  return (
    <div>
      {/* Page header */}
      <div className="page-header">
        <div className="page-header-text">
          <h1 style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
            {activeCatName ? (
              <>
                <span
                  style={{ color: 'var(--text-muted)', cursor: 'pointer', fontWeight: 700, fontSize: 22 }}
                  onClick={resetFilter}
                  title="Back to all products"
                >
                  Products
                </span>
                <span style={{ color: 'var(--border-bright)', fontWeight: 300 }}>›</span>
                <span style={{ color: 'var(--accent)' }}>{decodeURIComponent(activeCatName)}</span>
              </>
            ) : 'Products'}
          </h1>
          <p>
            {activeCatName
              ? <><span style={{ cursor: 'pointer', textDecoration: 'underline', textDecorationStyle: 'dotted' }} onClick={resetFilter}>← Back to all products</span></>
              : 'Manage your entire product catalogue.'}
          </p>
        </div>
        <button className="btn btn-primary" onClick={openAdd}>
          <IconPlus /> Add Product
        </button>
      </div>

      {/* Alert */}
      {alert && (
        <div className={`alert alert-${alert.type === 'error' ? 'error' : 'success'}`}>
          {alert.type === 'error' ? <IconAlertCircle /> : <IconCheck />}
          {alert.msg}
        </div>
      )}

      {/* ── Filter Bar ── */}
      <div className="card" style={{ marginBottom: 20 }}>
        <div className="card-header">
          <span className="card-title" style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ color: 'var(--accent)' }}><IconFilter /></span>
            Filter / Search
          </span>
          {isFiltered && (
            <button className="btn btn-secondary btn-sm" onClick={resetFilter}>
              <IconX /> Clear Filter
            </button>
          )}
        </div>
        <div className="card-body">
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 16 }}>
            {FILTER_MODES.map((m) => (
              <button
                key={m.value}
                onClick={() => setFilterMode(m.value)}
                style={{
                  padding: '5px 12px',
                  borderRadius: 'var(--radius-md)',
                  border: '1px solid',
                  fontSize: 12, fontWeight: 500,
                  cursor: 'pointer',
                  transition: 'all var(--transition)',
                  borderColor: filterMode === m.value ? 'var(--accent)' : 'var(--border)',
                  background:  filterMode === m.value ? 'var(--accent-dim)' : 'var(--bg-elevated)',
                  color:       filterMode === m.value ? 'var(--accent)' : 'var(--text-secondary)',
                }}
              >
                {m.label}
              </button>
            ))}
          </div>

          {filterMode !== 'all' && (
            <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', alignItems: 'flex-end' }}>
              {filterMode === 'name' && (
                <div className="form-group" style={{ flex: '1 1 220px', margin: 0 }}>
                  <label>Product Name</label>
                  <div style={{ position: 'relative' }}>
                    <span style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)', pointerEvents: 'none' }}><IconSearch /></span>
                    <input style={{ paddingLeft: 34 }} type="text" placeholder="e.g. Wireless Mouse"
                      value={filterName} onChange={(e) => setFilterName(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && applyFilter()} />
                  </div>
                </div>
              )}
              {filterMode === 'category_id' && (
                <div className="form-group" style={{ flex: '1 1 220px', margin: 0 }}>
                  <label>Category</label>
                  <select value={filterCatId} onChange={(e) => setFilterCatId(e.target.value)}>
                    <option value="">— Select category —</option>
                    {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </select>
                </div>
              )}
              {filterMode === 'category_name' && (
                <div className="form-group" style={{ flex: '1 1 220px', margin: 0 }}>
                  <label>Category Name</label>
                  <div style={{ position: 'relative' }}>
                    <span style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)', pointerEvents: 'none' }}><IconSearch /></span>
                    <input style={{ paddingLeft: 34 }} type="text" placeholder="e.g. Electronics"
                      value={filterCatName} onChange={(e) => setFilterCatName(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && applyFilter()} />
                  </div>
                </div>
              )}
              {filterMode === 'price_range' && (
                <>
                  <div className="form-group" style={{ flex: '1 1 140px', margin: 0 }}>
                    <label>Min Price (₹)</label>
                    <input type="number" min="0" step="0.01" placeholder="0.00"
                      value={filterPriceMin} onChange={(e) => setFilterPriceMin(e.target.value)} />
                  </div>
                  <div className="form-group" style={{ flex: '1 1 140px', margin: 0 }}>
                    <label>Max Price (₹)</label>
                    <input type="number" min="0" step="0.01" placeholder="9999.00"
                      value={filterPriceMax} onChange={(e) => setFilterPriceMax(e.target.value)} />
                  </div>
                </>
              )}
              <button className="btn btn-primary" onClick={applyFilter} disabled={filterLoading} style={{ marginBottom: 1 }}>
                {filterLoading ? 'Searching…' : <><IconSearch /> Search</>}
              </button>
            </div>
          )}
        </div>
      </div>

      {/* ── Products Table ── */}
      <div className="card">
        <div className="card-header">
          <span className="card-title">{isFiltered ? 'Filter Results' : 'All Products'}</span>
          <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>
            {products.length} {products.length === 1 ? 'product' : 'products'}
          </span>
        </div>
        <div className="table-wrapper">
          {loading ? (
            <div className="spinner"><div className="spinner-ring" /></div>
          ) : products.length === 0 ? (
            <div className="empty-state">
              <IconPackage />
              <p>{isFiltered ? 'No products match your filter.' : 'No products yet. Add your first product.'}</p>
            </div>
          ) : (
            <table>
              <thead>
                <tr>
                  <th>#</th>
                  <th>Product Name</th>
                  <th>Brand</th>
                  <th>Category</th>
                  <th>Price</th>
                  <th>Quantity</th>
                  <th>Description</th>
                  <th style={{ textAlign: 'right' }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {products.map((p) => (
                  <tr key={p.id}>
                    <td className="td-id">{p.id}</td>
                    <td className="td-name">{p.name}</td>
                    <td style={{ color: 'var(--text-secondary)' }}>{p.brand || '—'}</td>
                    <td><span className="badge badge-yellow">{getCatName(p)}</span></td>
                    <td>₹{Number(p.price).toFixed(2)}</td>
                    <td>
                      <span style={{ color: p.quantity > 0 ? 'var(--success)' : 'var(--danger)', fontWeight: 500 }}>
                        {p.quantity}
                      </span>
                    </td>
                    <td style={{ color: 'var(--text-secondary)', maxWidth: 180, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      {p.description || '—'}
                    </td>
                    {/* ── ACTION BUTTONS with visible labels ── */}
                    <td style={{ textAlign: 'right', whiteSpace: 'nowrap' }}>
                      <button
                        onClick={() => openEdit(p)}
                        style={{
                          display: 'inline-flex', alignItems: 'center', gap: 5,
                          padding: '5px 12px',
                          marginRight: 6,
                          borderRadius: 'var(--radius-md)',
                          border: '1px solid rgba(240,180,41,0.35)',
                          background: 'var(--accent-dim)',
                          color: 'var(--accent)',
                          fontSize: 12, fontWeight: 600,
                          cursor: 'pointer',
                          transition: 'all var(--transition)',
                        }}
                        onMouseEnter={e => { e.currentTarget.style.background = 'rgba(240,180,41,0.25)'; }}
                        onMouseLeave={e => { e.currentTarget.style.background = 'var(--accent-dim)'; }}
                      >
                        <IconEdit /> Edit
                      </button>
                      <button
                        onClick={() => setDeleteTarget(p)}
                        style={{
                          display: 'inline-flex', alignItems: 'center', gap: 5,
                          padding: '5px 12px',
                          borderRadius: 'var(--radius-md)',
                          border: '1px solid rgba(224,82,82,0.35)',
                          background: 'var(--danger-dim)',
                          color: 'var(--danger)',
                          fontSize: 12, fontWeight: 600,
                          cursor: 'pointer',
                          transition: 'all var(--transition)',
                        }}
                        onMouseEnter={e => { e.currentTarget.style.background = 'rgba(224,82,82,0.25)'; }}
                        onMouseLeave={e => { e.currentTarget.style.background = 'var(--danger-dim)'; }}
                      >
                        <IconTrash /> Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {/* ── Add / Edit Modal ── */}
      {showModal && (
        <Modal
          title={editTarget ? `Edit — ${editTarget.name}` : 'Add Product'}
          onClose={() => setShowModal(false)}
        >
          <form onSubmit={handleSubmit} className="form-grid form-grid-2">
            <div className="form-group">
              <label htmlFor="p-name">Product Name *</label>
              <input id="p-name" type="text" placeholder="e.g. Wireless Mouse"
                value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })}
                required autoFocus />
            </div>
            <div className="form-group">
              <label htmlFor="p-brand">Brand</label>
              <input id="p-brand" type="text" placeholder="e.g. Logitech"
                value={form.brand} onChange={(e) => setForm({ ...form, brand: e.target.value })} />
            </div>
            <div className="form-group">
              <label htmlFor="p-category">Category</label>
              <select id="p-category" value={form.categoryId}
                onChange={(e) => setForm({ ...form, categoryId: e.target.value })}>
                <option value="">— Select category —</option>
                {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </div>
            <div className="form-group">
              <label htmlFor="p-price">Price (₹) *</label>
              <input id="p-price" type="number" min="0" step="0.01" placeholder="0.00"
                value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} required />
            </div>
            <div className="form-group">
              <label htmlFor="p-qty">Quantity *</label>
              <input id="p-qty" type="number" min="0" step="1" placeholder="0"
                value={form.quantity} onChange={(e) => setForm({ ...form, quantity: e.target.value })} required />
            </div>
            <div className="form-group full-width">
              <label htmlFor="p-desc">Description</label>
              <textarea id="p-desc" placeholder="Optional description…"
                value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
            </div>
            <div className="form-actions">
              <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>Cancel</button>
              <button type="submit" className="btn btn-primary" disabled={saving || !form.name.trim()}>
                {saving ? 'Saving…' : editTarget ? 'Save Changes' : 'Add Product'}
              </button>
            </div>
          </form>
        </Modal>
      )}

      {/* ── Delete Confirm ── */}
      {deleteTarget && (
        <ConfirmDialog
          message={`Delete "${deleteTarget.name}"? This action cannot be undone.`}
          onConfirm={handleDelete}
          onCancel={() => setDeleteTarget(null)}
          loading={deleting}
        />
      )}
    </div>
  );
}
