import API from './axiosConfig';

const categoryService = {
  // GET /category/all
  getAllCategories: async () => {
    const response = await API.get('/category/all');
    return response.data;
  },

  // POST /category/add
  addCategory: async (categoryData) => {
    const response = await API.post('/category/add', categoryData);
    return response.data;
  },

  // PUT /category/add/{id}
  editCategory: async (id, categoryData) => {
    const response = await API.put(`/category/add/${id}`, categoryData);
    return response.data;
  },

  // DELETE /category/delete/{id}
  deleteCategory: async (id) => {
    const response = await API.delete(`/category/delete/${id}`);
    return response.data;
  },
};

export default categoryService;
