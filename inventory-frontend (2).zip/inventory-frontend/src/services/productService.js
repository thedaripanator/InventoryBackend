import API from './axiosConfig';

const productService = {
  // GET /products/all
  getAllProducts: async () => {
    const response = await API.get('/products/all');
    return response.data;
  },

  // POST /products/add
  addProduct: async (productData) => {
    const response = await API.post('/products/add', productData);
    return response.data;
  },

  // PUT /products/edit/{id}
  updateProduct: async (id, productData) => {
    const response = await API.put(`/products/edit/${id}`, productData);
    return response.data;
  },

  // DELETE /products/delete/{id}
  deleteProduct: async (id) => {
    const response = await API.delete(`/products/delete/${id}`);
    return response.data;
  },

  // GET /products/category/{id}
  getProductsByCategory: async (categoryId) => {
    const response = await API.get(`/products/category/${categoryId}`);
    return response.data;
  },

  // GET /products/name/{name}
  getProductsByName: async (name) => {
    const response = await API.get(`/products/name/${name}`);
    return response.data;
  },

  // GET /products/categoryname/{name}
  getProductsByCategoryName: async (name) => {
    const response = await API.get(`/products/categoryname/${name}`);
    return response.data;
  },

  // GET /products/price/{price1}/{price2}
  getProductsByPriceRange: async (price1, price2) => {
    const response = await API.get(`/products/price/${price1}/${price2}`);
    return response.data;
  },
};

export default productService;
