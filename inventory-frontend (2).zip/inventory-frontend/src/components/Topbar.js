import React from 'react';
import { useLocation } from 'react-router-dom';

const titles = {
  '/dashboard':  { title: 'Dashboard',           sub: 'Overview of your inventory' },
  '/categories': { title: 'Category Management', sub: 'Organise product categories' },
  '/products':   { title: 'Product Management',  sub: 'Manage your product catalogue' },
};

export default function Topbar() {
  const location = useLocation();
  const info = titles[location.pathname] || { title: 'Inventory System', sub: '' };
  const now = new Date().toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });

  return (
    <header className="topbar">
      <span className="topbar-title">{info.title}</span>
      <span className="topbar-meta">{now}</span>
    </header>
  );
}
